"use client";

import React, { useMemo, useState } from "react";

const money = (v) =>
  new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL", maximumFractionDigits: 0 }).format(v);

const months = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"];

const monthly = [
  { mes: "Jan", faturamento: 1900000, lucro: 420000, custos: 1220000, descontos: 85000 },
  { mes: "Fev", faturamento: 2140000, lucro: 455000, custos: 1420000, descontos: 92000 },
  { mes: "Mar", faturamento: 2070000, lucro: 438000, custos: 1460000, descontos: 98000 },
  { mes: "Abr", faturamento: 2450000, lucro: 562500, custos: 1720000, descontos: 120000 },
  { mes: "Mai", faturamento: 2620000, lucro: 610000, custos: 1680000, descontos: 125000 },
  { mes: "Jun", faturamento: 2520000, lucro: 585000, custos: 1660000, descontos: 115000 },
  { mes: "Jul", faturamento: 2730000, lucro: 635000, custos: 1750000, descontos: 132000 },
  { mes: "Ago", faturamento: 2600000, lucro: 605000, custos: 1690000, descontos: 121000 },
  { mes: "Set", faturamento: 2700000, lucro: 620000, custos: 1710000, descontos: 128000 },
  { mes: "Out", faturamento: 2710000, lucro: 625000, custos: 1730000, descontos: 129000 },
  { mes: "Nov", faturamento: 2650000, lucro: 600000, custos: 1700000, descontos: 122000 },
  { mes: "Dez", faturamento: 2810000, lucro: 660000, custos: 1790000, descontos: 135000 },
];

const products = [
  ["Monitor 24\"", 1250, 100],
  ["Teclado Mecânico", 980, 78],
  ["Mouse Gamer", 870, 70],
  ["Cadeira Escritório", 760, 61],
  ["Notebook Dell", 550, 44],
  ["Impressora HP", 510, 41],
  ["Mesa Escritório", 480, 38],
  ["SSD 480GB", 390, 31],
];

const clients = [
  ["Cliente Exemplo LTDA", "R$ 245.000", "R$ 1.250", "06/05/2025", 12],
  ["Tech Solutions", "R$ 189.500", "R$ 980", "05/05/2025", 8],
  ["Comércio Silva", "R$ 145.200", "R$ 720", "04/05/2025", 6],
  ["Empresa Almeida", "R$ 125.300", "R$ 650", "03/05/2025", 7],
];

function Icon({ children, color }) {
  return <div className="icon" style={{ background: color }}>{children}</div>;
}

function Card({ title, value, sub, color, children }) {
  return (
    <div className="kpi cardGlow" style={{ "--glow": color }}>
      <Icon color={color}>{children}</Icon>
      <div>
        <div className="kpiTitle">{title}</div>
        <div className="kpiValue">{value}</div>
        <div className="kpiSub">↑ {sub} vs mês anterior</div>
      </div>
    </div>
  );
}

function SelectBox({ label, value = "Todos" }) {
  return (
    <div className="selectBox">
      <span>{label}</span>
      <strong>{value}</strong>
      <em>⌄</em>
    </div>
  );
}

function LineChart() {
  const max = Math.max(...monthly.map((m) => m.faturamento));
  const points = monthly.map((m, i) => `${42 + i * 67},${205 - (m.faturamento / max) * 145}`).join(" ");
  const pointsLucro = monthly.map((m, i) => `${42 + i * 67},${205 - (m.lucro / 700000) * 145}`).join(" ");
  const pointsCustos = monthly.map((m, i) => `${42 + i * 67},${205 - (m.custos / 1900000) * 145}`).join(" ");
  return (
    <div className="chartBox large">
      <div className="chartHeader">
        <h3>Evolução Mensal</h3>
        <div className="legend"><span className="y"/>Faturamento <span className="g"/>Lucro <span className="r"/>Custos</div>
      </div>
      <svg viewBox="0 0 820 250" className="lineSvg">
        {[0, 1, 2, 3].map((i) => <line key={i} x1="30" x2="800" y1={55 + i * 45} y2={55 + i * 45} className="gridLine" />)}
        <polyline points={pointsCustos} className="line red" />
        <polyline points={pointsLucro} className="line green" />
        <polyline points={points} className="line yellow" />
        {monthly.map((m, i) => <circle key={m.mes} cx={42 + i * 67} cy={205 - (m.faturamento / max) * 145} r="5" className="dot" />)}
        {months.map((m, i) => <text key={m} x={35 + i * 67} y="236" className="axis">{m}</text>)}
      </svg>
      <div className="tooltipFake"><b>Maio</b><br/>Faturamento: R$ 2.620.000<br/><span>Lucro: R$ 610.000</span><br/>Crescimento: +18,6%</div>
    </div>
  );
}

function Donut({ title }) {
  return (
    <div className="chartBox donutCard">
      <h3>{title}</h3>
      <div className="donutWrap">
        <div className="donut"><div><b>R$ 2,45M</b><small>Total</small></div></div>
        <div className="donutLegend">
          {[["Informática", "28,5%"], ["Eletrônicos", "22,1%"], ["Móveis", "16,3%"], ["Utilidades", "14,8%"], ["Outros", "9,6%"]].map((x, i)=><p key={x[0]}><span className={`c${i}`}/>{x[0]} <b>{x[1]}</b></p>)}
        </div>
      </div>
    </div>
  );
}

function Gauge() {
  return <div className="chartBox small center"><h3>Meta vs Realizado</h3><div className="gauge"><div className="needle" /></div><strong className="percent">72,5%</strong><p>Meta: R$ 3.000.000</p><p>Realizado: R$ 2.175.000</p></div>;
}

export default function Page() {
  const [tv, setTv] = useState(false);
  const updated = useMemo(() => new Date().toLocaleString("pt-BR"), []);

  return (
    <div className={tv ? "page tv" : "page"}>
      <style>{css}</style>
      <aside className="sidebar">
        <div><div className="logo"><div className="bars"><i/><i/><i/><i/></div><div><h1>BI SERVICE</h1><p>ERP EDITION</p></div></div>
        <nav>{["⌂ Executivo", "↗ Comercial", "$ Financeiro", "◇ Estoque", "♧ Clientes", "⌁ Produtos", "▤ Fiscal", "◉ DRE", "◎ Metas"].map((n,i)=><a className={i===0?"active":""} key={n}>{n}</a>)}</nav></div>
        <button className="tvBtn" onClick={() => setTv(!tv)}>🏆 Modo TV<br/><small>Tela cheia</small></button>
      </aside>
      <main>
        <header><div><h2>Dashboard Executivo</h2><p>Visão geral completa da sua empresa</p></div><div className="topRight"><span>Atualizado em:<br/><b>{updated}</b></span><button>⟳</button><label><input type="checkbox" defaultChecked/> Auto</label></div></header>
        <section className="filters"><SelectBox label="Empresa"/><SelectBox label="Ano" value="2025"/><SelectBox label="Mês" value="Maio"/><SelectBox label="Vendedor"/><SelectBox label="Cliente"/><SelectBox label="Produto"/><SelectBox label="Categoria"/><SelectBox label="Forma Pgto"/><SelectBox label="Cidade"/><SelectBox label="Status"/><button className="goldBtn">⎚ Limpar Filtros</button><button className="moreBtn">☰ Mais Filtros</button></section>
        <section className="kpis"><Card title="Faturamento Total" value="R$ 2.450.000" sub="18,6%" color="linear-gradient(135deg,#f7b731,#d88900)">$</Card><Card title="Lucro Total" value="R$ 562.500" sub="24,3%" color="linear-gradient(135deg,#42d96b,#159947)">↗</Card><Card title="Ticket Médio" value="R$ 315,75" sub="12,7%" color="linear-gradient(135deg,#3182ff,#155ad1)">🛒</Card><Card title="Qtde Vendas" value="7.760" sub="15,4%" color="linear-gradient(135deg,#a855f7,#7e22ce)">▣</Card><Card title="Clientes Ativos" value="1.250" sub="8,2%" color="linear-gradient(135deg,#fb923c,#ea580c)">👥</Card><Card title="Margem Média" value="23,15%" sub="3,6%" color="linear-gradient(135deg,#84cc16,#4d7c0f)">%</Card></section>
        <section className="grid mainGrid"><LineChart/><Donut title="Vendas por Categoria"/><div className="chartBox products"><h3>Top 10 Produtos - Mais Vendidos</h3>{products.map(p=><div className="barRow" key={p[0]}><span>{p[0]}</span><div><i style={{width:`${p[2]}%`}}/></div><b>{p[1]}</b></div>)}</div><div className="chartBox table"><h3>Ranking Clientes</h3><table><tbody>{clients.map((c,i)=><tr key={c[0]}><td>{i+1}</td><td>{c[0]}</td><td>{c[1]}</td><td>{c[2]}</td><td>{c[4]}</td></tr>)}</tbody></table></div><Donut title="Formas de Pagamento"/><div className="chartBox table"><h3>Comparativo entre Empresas</h3><table><tbody>{[["Loja Matriz","R$ 1.250.000","R$ 312.000","24,9%"],["Loja Centro","R$ 850.000","R$ 186.000","21,9%"],["Loja Sul","R$ 350.000","R$ 64.500","18,4%"]].map(r=><tr key={r[0]}>{r.map(x=><td key={x}>{x}</td>)}</tr>)}</tbody></table></div><div className="chartBox small"><h3>Fluxo de Caixa</h3><div className="cashBars">{[35,25,55,48,65,38,70,58,78,66,88,74].map((h,i)=><i key={i} style={{height:`${h}%`}}/>)}</div></div><div className="chartBox small"><h3>Estoque - Situação</h3><div className="stock"><p><b className="redTxt">45</b> Crítico</p><p><b className="yellowTxt">78</b> Atenção</p><p><b className="greenTxt">342</b> Normal</p></div></div><Gauge/><div className="chartBox small dre"><h3>DRE Resumido</h3><p><span>Receita Bruta</span><b>R$ 2.450.000</b></p><p><span>(-) Custos</span><b>-R$ 1.720.000</b></p><p><span>(-) Despesas</span><b>-R$ 150.000</b></p><h4><span>Lucro Líquido</span><b>R$ 460.000</b></h4></div></section>
      </main>
    </div>
  );
}

const css = `
*{box-sizing:border-box}body{margin:0;background:#05070c;color:#fff;font-family:Inter,Segoe UI,Arial,sans-serif}.page{min-height:100vh;display:flex;background:radial-gradient(circle at 30% -10%,#2a2108 0,#05070c 36%,#02030a 100%)}.sidebar{width:255px;background:linear-gradient(180deg,#0d0e12,#06070a);border-right:1px solid #b8860b55;padding:24px 16px;display:flex;flex-direction:column;justify-content:space-between;position:sticky;top:0;height:100vh}.logo{display:flex;gap:14px;align-items:center;margin-bottom:34px}.logo h1{font-size:24px;margin:0;font-weight:900}.logo p{margin:0;color:#f2b01e;font-size:12px;font-weight:800}.bars{display:flex;gap:4px;align-items:end;height:38px}.bars i{width:8px;border-radius:5px;background:linear-gradient(#ffd56b,#d89200);box-shadow:0 0 15px #f3b31a}.bars i:nth-child(1){height:16px}.bars i:nth-child(2){height:25px}.bars i:nth-child(3){height:33px}.bars i:nth-child(4){height:38px}nav{display:grid;gap:8px}nav a{padding:14px 16px;color:#d7d7d7;border-radius:13px;border:1px solid transparent;text-decoration:none;font-size:14px}nav a.active,nav a:hover{background:linear-gradient(90deg,#8a650f66,#16130b);border-color:#d6a31d55;color:#fff}.tvBtn{background:#0f0f10;border:1px solid #d39a0d;border-radius:14px;color:#f2b01e;padding:17px;font-weight:900;text-transform:uppercase}main{flex:1;padding:22px 24px 30px;min-width:0}header{display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #9f7b1944;padding-bottom:16px;margin-bottom:14px}header h2{font-size:31px;text-transform:uppercase;margin:0;font-weight:950;letter-spacing:.3px}header p{margin:4px 0 0;color:#c8c8c8}.topRight{display:flex;align-items:center;gap:18px;color:#cfcfcf;font-size:12px}.topRight button{background:#111;border:1px solid #444;color:white;border-radius:50%;width:38px;height:38px}.topRight input{accent-color:#44d62c}.filters{background:linear-gradient(135deg,#151515,#0c0d10);border:1px solid #2b2b2e;border-radius:14px;padding:12px;display:grid;grid-template-columns:repeat(5,minmax(135px,1fr)) 145px 135px;gap:8px;margin-bottom:18px}.selectBox{height:55px;border:1px solid #38383d;background:#18191d;border-radius:9px;padding:8px 36px 7px 12px;position:relative}.selectBox span{display:block;text-transform:uppercase;color:#ddd;font-size:11px}.selectBox strong{font-size:14px}.selectBox em{position:absolute;right:14px;top:16px;font-style:normal}.goldBtn,.moreBtn{border-radius:9px;border:1px solid #7e610f;background:linear-gradient(135deg,#d79b1d,#8c610d);color:#fff;font-weight:850}.moreBtn{background:#101114;border-color:#555}.kpis{display:grid;grid-template-columns:repeat(6,1fr);gap:10px;margin-bottom:14px}.kpi{background:linear-gradient(135deg,#18191d,#0c0d10);border:1px solid #2f3034;border-radius:14px;padding:16px;display:flex;gap:12px;align-items:center;min-height:96px}.cardGlow{box-shadow:0 0 24px color-mix(in srgb,var(--glow),transparent 80%)}.icon{width:48px;height:48px;border-radius:50%;display:grid;place-items:center;font-weight:900;font-size:20px;box-shadow:0 0 18px #ffffff22}.kpiTitle{text-transform:uppercase;color:#d8d8d8;font-size:11px;font-weight:800}.kpiValue{font-size:20px;font-weight:950;margin-top:3px}.kpiSub{font-size:12px;color:#55e64f;margin-top:4px}.grid{display:grid;gap:12px}.mainGrid{grid-template-columns:2fr 1.15fr 1.55fr}.chartBox{background:linear-gradient(135deg,#151619,#0b0c10);border:1px solid #303137;border-radius:14px;padding:16px;box-shadow:inset 0 1px 0 #ffffff0c}.chartBox h3{margin:0 0 14px;text-transform:uppercase;font-size:15px}.large{grid-column:span 2;position:relative}.small{min-height:210px}.chartHeader{display:flex;justify-content:space-between}.legend{font-size:12px;color:#ddd}.legend span{display:inline-block;width:18px;height:6px;border-radius:8px;margin:0 6px}.y{background:#e7a51d}.g{background:#62c84d}.r{background:#f04c48}.lineSvg{width:100%;height:250px}.gridLine{stroke:#ffffff13}.line{fill:none;stroke-width:4;stroke-linecap:round;stroke-linejoin:round}.yellow{stroke:#f2aa16}.green{stroke:#65ca4f}.red{stroke:#e64646}.dot{fill:#f2aa16;stroke:white;stroke-width:2}.axis{fill:#d8d8d8;font-size:12px}.tooltipFake{position:absolute;left:34%;top:37%;background:#05070ce8;border:1px solid #555;border-radius:8px;padding:10px;font-size:12px;box-shadow:0 15px 40px #000}.tooltipFake span{color:#68e15e}.donutWrap{display:flex;align-items:center;gap:20px}.donut{width:195px;height:195px;border-radius:50%;background:conic-gradient(#2775d8 0 29%,#f2b02c 29% 50%,#ef7131 50% 66%,#75c94d 66% 81%,#9853d9 81% 91%,#4cc3e6 91%);display:grid;place-items:center}.donut:before{content:"";position:absolute}.donut div{width:94px;height:94px;border-radius:50%;background:#111318;display:grid;place-items:center;text-align:center}.donut b{font-size:19px}.donut small{text-transform:uppercase;color:#ddd}.donutLegend{flex:1}.donutLegend p{display:flex;gap:8px;align-items:center;justify-content:space-between;color:#ddd}.donutLegend span{width:11px;height:11px;border-radius:3px}.c0{background:#2775d8}.c1{background:#f2b02c}.c2{background:#ef7131}.c3{background:#75c94d}.c4{background:#9853d9}.products{grid-column:span 1}.barRow{display:grid;grid-template-columns:135px 1fr 45px;gap:10px;align-items:center;margin:10px 0;font-size:13px}.barRow div{height:18px;background:#0c0d10;border-radius:4px;overflow:hidden}.barRow i{height:100%;display:block;background:linear-gradient(90deg,#d8940d,#f5bd33)}.table{grid-column:span 1}.table table{width:100%;border-collapse:collapse;font-size:13px}.table td{padding:10px;border-bottom:1px solid #ffffff12;color:#e6e6e6}.cashBars{height:170px;display:flex;gap:7px;align-items:end}.cashBars i{flex:1;background:linear-gradient(#48d25d,#136d25);border-radius:6px 6px 0 0}.stock p{background:#0c0d10;border:1px solid #25262a;border-radius:10px;padding:14px;display:flex;justify-content:space-between}.redTxt{color:#ff5454}.yellowTxt{color:#f5b827}.greenTxt{color:#52e864}.center{text-align:center}.gauge{width:190px;height:95px;border-radius:190px 190px 0 0;border:22px solid #f5cf28;border-bottom:0;margin:20px auto 0;position:relative;background:linear-gradient(90deg,#55c941,#f7d62d,#f2f2f2)}.needle{position:absolute;width:80px;height:4px;background:#d7d7d7;left:50%;bottom:0;transform-origin:left center;transform:rotate(-28deg);border-radius:5px}.percent{font-size:36px}.dre p,.dre h4{display:flex;justify-content:space-between;border-bottom:1px solid #ffffff10;padding-bottom:10px}.dre h4{color:#45e04c;font-size:17px;border:0}.tv .sidebar{display:none}.tv main{padding:12px}.tv header{display:none}@media(max-width:1350px){.kpis{grid-template-columns:repeat(3,1fr)}.mainGrid{grid-template-columns:1fr 1fr}.large{grid-column:span 2}.filters{grid-template-columns:repeat(4,1fr)}}@media(max-width:900px){.sidebar{display:none}.kpis,.mainGrid,.filters{grid-template-columns:1fr}.large{grid-column:span 1}header{display:block}.topRight{margin-top:12px}.donutWrap{display:block}.donut{margin:auto}.page{display:block}}`;
