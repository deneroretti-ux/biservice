"use client";

import React, { useMemo, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  BarChart3,
  BriefcaseBusiness,
  Calculator,
  ChartNoAxesCombined,
  ChevronLeft,
  ChevronRight,
  ClipboardList,
  Gauge,
  Gem,
  LayoutDashboard,
  LineChart,
  Megaphone,
  PackageSearch,
  SearchCheck,
  ShoppingBag,
  Store,
  Target,
  Trophy,
  Users,
} from "lucide-react";

const gold = "#d4a72c";
const gold2 = "#f5c542";

const menu = [
  { title: "EXECUTIVO", href: "/bi-service/executivo", icon: LayoutDashboard, group: "Visão Geral" },
  { title: "TICKET MÉDIO", href: "/bi-service/dashboard-consultor#ticket-medio", icon: Gauge, group: "Comercial" },
  { title: "PA", href: "/bi-service/dashboard-consultor#pa", icon: ShoppingBag, group: "Comercial" },
  { title: "META", href: "/bi-service/dashboard-consultor#metas", icon: Target, group: "Comercial" },
  { title: "SELLOUT", href: "/bi-service/dashboard-consultor#sellout", icon: ChartNoAxesCombined, group: "Comercial" },
  { title: "CONSULTORES", href: "/bi-service/dashboard-consultor", icon: Users, group: "Comercial" },
  { title: "CAMPANHAS", href: "/bi-service/dashboard-consultor#campanhas", icon: Megaphone, group: "Comercial" },
  { title: "EVOLUÇÃO MENSAL", href: "/bi-service/dashboard-consultor#evolucao", icon: LineChart, group: "Comercial" },
  { title: "RANKING", href: "/bi-service/dashboard-consultor#ranking", icon: Trophy, group: "Comercial" },
  { title: "METAS POR VENDEDOR", href: "/bi-service/dashboard-consultor#metas-vendedor", icon: ClipboardList, group: "Comercial" },
  { title: "DRE", href: "/bi-service/dashboard-rateio#dre", icon: Calculator, group: "Financeiro" },
  { title: "MARGEM", href: "/bi-service/dashboard-rateio#margem", icon: Gem, group: "Financeiro" },
  { title: "COMPARATIVO LOJAS", href: "/bi-service/dashboard-rateio#comparativo", icon: Store, group: "Financeiro" },
  { title: "RUPTURA", href: "/bi-service/dashboard-estoque#ruptura", icon: PackageSearch, group: "Estoque" },
  { title: "ESTOQUE", href: "/bi-service/dashboard-estoque", icon: SearchCheck, group: "Estoque" },
  { title: "CONFERENTE", href: "/bi-service/dashboard", icon: BriefcaseBusiness, group: "Operação" },
];

function isActive(pathname, href) {
  const base = href.split("#")[0];
  return pathname === base || (base !== "/bi-service/executivo" && pathname.startsWith(base));
}

function SectionTitle({ children, collapsed }) {
  if (collapsed) return <div style={{ height: 12 }} />;
  return <div style={{ color: "rgba(255,255,255,.36)", fontSize: 10, letterSpacing: 1.4, fontWeight: 800, margin: "18px 14px 8px" }}>{children}</div>;
}

export default function BiServiceLayout({ children }) {
  const pathname = usePathname();
  const [collapsed, setCollapsed] = useState(false);

  const grouped = useMemo(() => {
    return menu.reduce((acc, item) => {
      acc[item.group] = acc[item.group] || [];
      acc[item.group].push(item);
      return acc;
    }, {});
  }, []);

  return (
    <div style={{ minHeight: "100vh", background: "radial-gradient(circle at top left, rgba(212,167,44,.12), transparent 34%), #050505", color: "#fff", display: "flex", overflow: "hidden" }}>
      <aside style={{ width: collapsed ? 82 : 282, transition: "width .22s ease", minHeight: "100vh", borderRight: "1px solid rgba(212,167,44,.22)", background: "linear-gradient(180deg, #080808 0%, #030303 100%)", position: "sticky", top: 0, display: "flex", flexDirection: "column", boxShadow: "12px 0 40px rgba(0,0,0,.4)", zIndex: 50 }}>
        <div style={{ height: 82, display: "flex", alignItems: "center", gap: 12, padding: collapsed ? "0 17px" : "0 22px", borderBottom: "1px solid rgba(212,167,44,.16)" }}>
          <div style={{ width: 43, height: 43, borderRadius: 14, background: "linear-gradient(135deg, #654600, #f5c542)", display: "grid", placeItems: "center", boxShadow: "0 0 22px rgba(245,197,66,.32)" }}>
            <BarChart3 size={24} color="#090909" />
          </div>
          {!collapsed && (
            <div style={{ lineHeight: 1.08 }}>
              <div style={{ fontWeight: 900, letterSpacing: .5, fontSize: 20 }}>BI SERVICE</div>
              <div style={{ color: gold2, fontWeight: 800, fontSize: 11, letterSpacing: 1.5 }}>FRANQUIA EDITION</div>
            </div>
          )}
        </div>

        <nav style={{ flex: 1, overflowY: "auto", padding: "12px 8px 18px" }}>
          {Object.entries(grouped).map(([group, items]) => (
            <div key={group}>
              <SectionTitle collapsed={collapsed}>{group}</SectionTitle>
              {items.map((item) => {
                const Icon = item.icon;
                const active = isActive(pathname, item.href);
                return (
                  <Link key={item.title} href={item.href} title={item.title} style={{ height: 44, display: "flex", alignItems: "center", gap: 12, padding: collapsed ? "0 17px" : "0 14px", margin: "4px 0", borderRadius: 12, textDecoration: "none", color: active ? "#fff" : "rgba(255,255,255,.76)", background: active ? "linear-gradient(90deg, rgba(212,167,44,.42), rgba(212,167,44,.08))" : "transparent", border: active ? "1px solid rgba(245,197,66,.35)" : "1px solid transparent", boxShadow: active ? "0 0 22px rgba(212,167,44,.12)" : "none", fontSize: 12, fontWeight: active ? 800 : 650 }}>
                    <Icon size={20} color={active ? gold2 : "rgba(255,255,255,.72)"} />
                    {!collapsed && <span>{item.title}</span>}
                  </Link>
                );
              })}
            </div>
          ))}
        </nav>

        <div style={{ padding: 12, borderTop: "1px solid rgba(212,167,44,.14)" }}>
          <button onClick={() => setCollapsed(!collapsed)} style={{ width: "100%", height: 42, borderRadius: 12, border: "1px solid rgba(212,167,44,.28)", background: "rgba(212,167,44,.10)", color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", gap: 8, cursor: "pointer", fontWeight: 800 }}>
            {collapsed ? <ChevronRight size={18} /> : <ChevronLeft size={18} />}
            {!collapsed && "RECOLHER MENU"}
          </button>
        </div>
      </aside>

      <main style={{ flex: 1, minWidth: 0, height: "100vh", overflowY: "auto", background: "linear-gradient(135deg, rgba(255,255,255,.025), transparent 40%)" }}>
        <div style={{ minHeight: "100vh" }}>{children}</div>
      </main>
    </div>
  );
}
