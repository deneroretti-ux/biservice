BI SERVICE — FASE 1 UNIFICAÇÃO / PADRÃO VISUAL

COMO INSTALAR:

1) Extraia este ZIP.
2) Copie a pasta "app" para a raiz do seu projeto:

C:\PORTAL_BOTI\unified-nextjs-full-integrated\

3) Aceite mesclar/substituir quando o Windows pedir.

ESTRUTURA QUE SERÁ CRIADA:

app\bi-service\layout.jsx
app\bi-service\executivo\page.jsx

URL PARA TESTAR:

http://localhost:3000/bi-service/executivo

IMPORTANTE:
Essa versão respeita sua estrutura atual mostrada no print:
app\bi-service\dashboard
app\bi-service\dashboard-consultor
app\bi-service\dashboard-estoque
app\bi-service\dashboard-rateio

O layout.jsx dentro de app\bi-service padroniza a lateral/menu visual para todas as rotas dentro de /bi-service.
